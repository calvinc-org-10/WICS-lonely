"""
    Calvin menu and utility system
"""

